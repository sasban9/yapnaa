<?PHP


	function table()
	{
		$tb = array(
					'tb0'	=>	'super_admin',  
					'tb1'	=>	'main_category', 
					'tb2'	=>	'sub_category',  
					'tb3'	=>	'business_stores',  
					'tb4'	=>	'store_products',  
					'tb5'	=>	'user_cart',  
					'tb6'	=>	'app_version',  
					'tb7'	=>	'users',  
					'tb8'	=>	'store_tickets',  
					'tb9'	=>	'store_service_tax',  
					'tb10'	=>	'ticket_master_order',  
					'tb11'	=>	'ticket_order_item_details',  
					'tb12'	=>	'b_store_slider',  
					'tb13'	=>	'orders',  
					'tb14'	=>	'order_item_details',  
					'tb15'	=>	'store_checkout_users'  
					);
		return $tb;

	}

	 
	

?>